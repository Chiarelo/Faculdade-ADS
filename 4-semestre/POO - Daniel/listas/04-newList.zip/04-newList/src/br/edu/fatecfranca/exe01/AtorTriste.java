package br.edu.fatecfranca.exe01;

public class AtorTriste extends Ator {

    @Override
    public void ato() {
        System.out.println("Ator Triste");
    }
}
