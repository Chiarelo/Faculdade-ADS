package br.edu.fatecfranca.exe01;

public abstract class Ator {
    public abstract void ato();
}
