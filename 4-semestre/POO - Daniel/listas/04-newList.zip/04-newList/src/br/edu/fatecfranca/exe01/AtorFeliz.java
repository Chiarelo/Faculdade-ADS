package br.edu.fatecfranca.exe01;

public class AtorFeliz extends Ator{

    @Override
    public void ato() {
        System.out.println("Ator Feliz");
    }
}
