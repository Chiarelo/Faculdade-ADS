package br.edu.fatecfranca.teste;

import br.edu.fatecfranca.exe01.Palco;

public class MainPalco {
    public static void main(String[] args) {
        Palco palco = new Palco();
        palco.atuar();
        palco.altera();
        palco.atuar();
    }
}
